setwd("C:\\Users\\IT24101125\\Desktop\\IT24101125_Lab_04")
data<-read.table("DATA 4.txt",header = TRUE,sep =" " )
fix(data)
attach(data)

##2
##a
boxplot(X1,main="Box plot for Team Attendence",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X2,main="Box plot for Team Salary",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X3,main="Box plot for Years",outline=TRUE,outpch=8,horizontal=TRUE)

hist(X1,ylab = "Frequency",xlab = "Team Attendence",main = "Histogram for Team Attendence")
hist(X2,ylab = "Frequency",xlab = "Team Salary",main = "Histogram for Team Salary")
hist(X3,ylab = "Frequency",xlab = "Years",main = "Histogram for years")

stem(X1)
stem(X2)
stem(X3)

##b
mean(X1)
mean(X2)
mean(X3)

median(X1)
median(X2)
median(X3)

sd(X1)
sd(X2)
sd(X3)

##c
summary(X1)
summary(X2)
summary(X3)

quantile(X1)
quantile(X1)[2]
quantile(X1)[4]

##d
IQR(X1)
IQR(X2)
IQR(X3)

##3
get.mode<-function(y){
  counts<-table(X3)
  names(counts[counts==max(counts)])
}

get.mode(X3)
table(X3)
counts<-table(X3)
max(counts)
counts==max(counts)
counts[counts==max(counts)]
names(counts[counts==max(counts)])

##4
get.outliers<-function(z){
  q1<-quantile(z)[2]
  q3<-quantile(z)[4]
  iqr<-q3-q1
  
  ub<-q3+1.5*iqr
  lb<-q1-1.5*iqr
  
  print(paste("Upper Bound =",ub))
  print(paste("Lower Bound =",lb))
  print(paste("Outliers:",paste(sort(z[z<lb | z<ub]),collapse = ",")))
  
}

get.outliers(X1)
get.outliers(X2)
get.outliers(X3)

##
get.outliers<-function(z){
  q1<-quantile(z)[2]
  q3<-quantile(z)[4]
  iqr<-q3-q1
  
  ub<-q3+1.5*iqr
  lb<-q1-1.5*iqr
  
  print(paste("upper Bound =",ub))
  print(paste("Lower Bound =",lb))
  
  print(paste("outliers:",past(sort(z[z<lb | z>ub]),collapse=",")))
}


##Exercise
##1
branch_data <- read.table("Exercise.txt", header=TRUE, sep=",")
##3
boxplot(branch_data$Sales_X1, main="Boxplot of Sales", horizontal=TRUE)
##4
summary(branch_data$Advertising_X2)
IQR_Advertising <- IQR(branch_data$Advertising_X2)
print(IQR_Advertising)
##5
get.outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

get.outliers(branch_data$Years_X3)

